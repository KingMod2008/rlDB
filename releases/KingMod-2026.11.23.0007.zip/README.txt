KingMod 2026.11.23.0007
Open KingMod Setup to install, update or remove the client. Close Rocket League before game-file changes. Your settings are preserved during updates.

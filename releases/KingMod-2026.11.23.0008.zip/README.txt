KingMod 2026.11.23.0008
Close Rocket League and KingMod before updating. Open KingMod first after updating so verified setup can finish.
Existing settings and game backups are preserved by the installer.

KingMod 2026.11.23.0009
Close Rocket League and KingMod before updating. Open KingMod first after updating and wait for preparation to finish.
Support logs are saved in Documents\KingMod. Previous game backups and settings are preserved.

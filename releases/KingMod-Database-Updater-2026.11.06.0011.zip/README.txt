Extract these files into KingMod\DatabaseDumps. Run Update_rlDB.bat and select a numbered dump folder. Existing dumps are preserved.

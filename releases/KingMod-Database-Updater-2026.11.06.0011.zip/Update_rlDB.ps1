[CmdletBinding()]
param(
    [string]$DumpRoot = $PSScriptRoot,
    [string]$DumpId,
    [string]$Repository = 'https://github.com/KingMod2008/rlDB.git',
    [string]$Branch = 'main',
    [string]$WorkDirectory,
    [string]$CompatibilityFile,
    [switch]$PrepareOnly,
    [switch]$Offline,
    [switch]$NoPause
)

$ErrorActionPreference = 'Stop'
function Invoke-Git {
    param([string[]]$GitArgs)
    & git @GitArgs
    if ($LASTEXITCODE -ne 0) { throw "Git failed (exit $LASTEXITCODE): git $($GitArgs -join ' ')" }
}
function Read-Git {
    param([string[]]$GitArgs)
    $output = @(& git @GitArgs)
    if ($LASTEXITCODE -ne 0) { throw "Git failed (exit $LASTEXITCODE): git $($GitArgs -join ' ')" }
    ($output -join "`n").TrimEnd([char[]]"`r`n")
}

$exitStatus = 1
try {
    if (!(Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git is missing. Install Git for Windows first.' }
    $rootPath = (Resolve-Path -LiteralPath $DumpRoot).Path
    # The same launcher also works when copied into a numbered dump folder.
    if ((Split-Path -Leaf $rootPath) -match '^\d+$') {
        if (!$DumpId) { $DumpId = Split-Path -Leaf $rootPath }
        $rootPath = Split-Path -Parent $rootPath
    }
    $choices = @(Get-ChildItem -LiteralPath $rootPath -Directory | Where-Object {
        $_.Name -match '^\d+$'
    } | Sort-Object Name -Descending)
    if (!$choices.Count) { throw 'No numbered database dump folders were found.' }
    if (!$DumpId) {
        Write-Host 'Available database dumps:'
        for ($index = 0; $index -lt $choices.Count; $index++) {
            $itemsFile = Join-Path $choices[$index].FullName 'items.json'
            if (Test-Path -LiteralPath $itemsFile) {
                $itemCount = (Get-Item -LiteralPath $itemsFile).Length
                Write-Host ('  [{0}] {1}  ({2:N1} MB items.json)' -f ($index + 1), $choices[$index].Name, ($itemCount / 1MB))
            } else { Write-Host ('  [{0}] {1}  (incomplete: items.json missing)' -f ($index + 1), $choices[$index].Name) }
        }
        $answer = (Read-Host 'Choose a list number or enter the full dump folder number; Q cancels').Trim()
        if ($answer -eq 'Q') { $exitStatus = 0; return }
        $selection = 0
        if ($answer.Length -lt 7 -and [int]::TryParse($answer, [ref]$selection) -and $selection -ge 1 -and $selection -le $choices.Count) {
            $DumpId = $choices[$selection - 1].Name
        } else { $DumpId = $answer }
    }
    $selected = @($choices | Where-Object { $_.Name -eq $DumpId })
    if ($selected.Count -ne 1) { throw 'Select one of the listed numbered dump folders.' }
    $sourcePath = $selected[0].FullName
    if (!(Test-Path -LiteralPath (Join-Path $sourcePath 'items.json'))) { throw "Dump $DumpId is incomplete: items.json is missing." }
    $files = @('image_export.log', 'image_progress.json', 'image_report.json', 'items.json', 'manifest.json', 'paints.json', 'rarities.json', 'titles.json', 'game-compatibility.json')
    # Validate before touching the checkout. Partial temporary exports are excluded.
    foreach ($name in $files | Where-Object { $_.EndsWith('.json') }) {
        $file = Join-Path $sourcePath $name
        if (Test-Path -LiteralPath $file) { Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json | Out-Null }
    }
    if (!$CompatibilityFile) {
        $bundled = Join-Path $PSScriptRoot 'game-compatibility.json'
        if (Test-Path -LiteralPath $bundled) { $CompatibilityFile = $bundled }
    }
    if ($CompatibilityFile) {
        $CompatibilityFile = (Resolve-Path -LiteralPath $CompatibilityFile).Path
        $catalog = Get-Content -LiteralPath $CompatibilityFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($catalog.schema_version -ne 1 -or !$catalog.fingerprints) { throw 'The compatibility catalog is invalid.' }
    }
    if (!$WorkDirectory) { $WorkDirectory = Join-Path $rootPath '.rlDB-updater\checkout' }
    $checkoutPath = [IO.Path]::GetFullPath($WorkDirectory)
    $sourcePrefix = $sourcePath.TrimEnd('\') + '\'
    if ($checkoutPath -eq $sourcePath -or $checkoutPath.StartsWith($sourcePrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'The checkout must be outside the selected dump folder.' }
    if (Test-Path -LiteralPath (Join-Path $checkoutPath '.git')) {
        $origin = Read-Git -GitArgs @('-C', $checkoutPath, 'remote', 'get-url', 'origin')
        if ($origin.TrimEnd('/') -ne $Repository.TrimEnd('/')) { throw 'The checkout belongs to a different repository; it was preserved.' }
        if (Read-Git -GitArgs @('-C', $checkoutPath, 'diff', '--name-only', '--diff-filter=U')) { throw 'The checkout has unresolved conflicts; it was preserved.' }
        $changed = Read-Git -GitArgs @('-C', $checkoutPath, 'status', '--porcelain', '-z', '--untracked-files=all')
        foreach ($line in ($changed -split "`0" | Where-Object { $_ })) {
            $relative = $line.Substring(3).Trim('"')
            if ($relative -notin $files -and !$relative.StartsWith('images/')) { throw "The checkout contains unrelated changes ($relative); it was preserved." }
        }
        if ($changed) {
            # Keep a recoverable Git snapshot of the previous failed/selected
            # update, then bring the clean managed checkout up to date.
            Invoke-Git -GitArgs @('-C', $checkoutPath, 'stash', 'push', '--include-untracked', '-m', "rlDB updater before selecting $DumpId")
        }
        Write-Host 'Reusing the existing checkout...'
        if (!$Offline) {
            Invoke-Git -GitArgs @('-C', $checkoutPath, 'fetch', '--depth', '1', 'origin', $Branch)
            Invoke-Git -GitArgs @('-C', $checkoutPath, 'merge', '--ff-only', "origin/$Branch")
        } else { Write-Host 'Offline preparation: retaining the existing GitHub base.' }
    } else {
        if (Test-Path -LiteralPath $checkoutPath) { throw 'The checkout directory exists without Git metadata; choose another WorkDirectory.' }
        New-Item -ItemType Directory -Path (Split-Path -Parent $checkoutPath) -Force | Out-Null
        Write-Host 'Cloning rlDB once; this checkout is retained for future updates...'
        if ($Offline) { throw 'Offline preparation requires an existing checkout.' }
        $cloneArgs = @('clone', '--depth', '1', '--single-branch', '--branch', $Branch)
        if (Test-Path -LiteralPath $Repository -PathType Container) { $cloneArgs += '--local' }
        Invoke-Git -GitArgs ($cloneArgs + @($Repository, $checkoutPath))
    }
    $stagedPaths = [Collections.Generic.List[string]]::new()
    foreach ($name in $files) {
        $file = Join-Path $sourcePath $name
        if (Test-Path -LiteralPath $file) {
            Write-Host "Updating $name"
            Copy-Item -LiteralPath $file -Destination (Join-Path $checkoutPath $name) -Force
            $stagedPaths.Add($name)
        }
    }
    if ($CompatibilityFile) {
        Copy-Item -LiteralPath $CompatibilityFile -Destination (Join-Path $checkoutPath 'game-compatibility.json') -Force
        if (!$stagedPaths.Contains('game-compatibility.json')) { $stagedPaths.Add('game-compatibility.json') }
    }
    $imagesPath = Join-Path $sourcePath 'images'
    if (Test-Path -LiteralPath $imagesPath) {
        Write-Host 'Updating images; existing images are retained...'
        & robocopy $imagesPath (Join-Path $checkoutPath 'images') /E /R:2 /W:1 /NFL /NDL /NJH /NJS
        if ($LASTEXITCODE -ge 8) { throw "Image copy failed (robocopy exit $LASTEXITCODE)." }
        $stagedPaths.Add('images')
    }
    Invoke-Git -GitArgs (@('-C', $checkoutPath, 'add', '-A', '--') + $stagedPaths.ToArray())
    $changes = Read-Git -GitArgs @('-C', $checkoutPath, 'diff', '--cached', '--stat')
    $ahead = [int](Read-Git -GitArgs @('-C', $checkoutPath, 'rev-list', '--count', "origin/$Branch..HEAD"))
    if (!$changes -and $ahead -eq 0) {
        Write-Host 'No changes detected. The selected database already matches GitHub.'
        $exitStatus = 0
        return
    }
    Write-Host "`nSelected dump: $DumpId"
    Write-Host $changes
    if ($PrepareOnly) { Write-Host 'Prepared successfully; nothing was committed or uploaded.'; $exitStatus = 0; return }
    if ((Read-Host 'Type UPLOAD to update GitHub, or press Enter to keep the prepared checkout').Trim() -ne 'UPLOAD') {
        Write-Host 'Prepared checkout retained. No upload performed.'
        $exitStatus = 0
        return
    }
    if ($changes) {
        foreach ($identity in @('user.name', 'user.email')) {
            & git -C $checkoutPath config --get $identity
            if ($LASTEXITCODE -ne 0) { throw "Git $identity is missing. Set it with: git config --global $identity YOUR_VALUE" }
        }
        Invoke-Git -GitArgs @('-C', $checkoutPath, 'commit', '-m', "Update rlDB from dump $DumpId")
    }
    Invoke-Git -GitArgs @('-C', $checkoutPath, 'push', 'origin', "HEAD:$Branch")
    Write-Host "SUCCESS: Dump $DumpId uploaded. Your original dump and reusable checkout were preserved."
    $exitStatus = 0
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'No source dump files were deleted. The checkout is retained for retry.'
} finally {
    if ($checkoutPath) { Write-Host "Checkout: $checkoutPath" }
    if (!$NoPause) { Read-Host 'Press Enter to close' | Out-Null }
    exit $exitStatus
}

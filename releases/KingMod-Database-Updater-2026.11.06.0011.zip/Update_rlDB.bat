@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title rlDB Database Updater
set "UPDATER=%~dp0Update_rlDB.ps1"
if not exist "%UPDATER%" set "UPDATER=%~dp0..\Update_rlDB.ps1"
if not exist "%UPDATER%" (
  echo ERROR: Keep Update_rlDB.ps1 beside this BAT or in the parent DatabaseDumps folder.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%UPDATER%" -DumpRoot "%~dp0." %*
exit /b %errorlevel%

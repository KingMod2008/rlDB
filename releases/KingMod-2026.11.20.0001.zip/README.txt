KingMod 2026.11.20.0001
Close KingMod before installing the update. Restart KingMod after updating.
Existing settings and game backups are preserved by the installer.

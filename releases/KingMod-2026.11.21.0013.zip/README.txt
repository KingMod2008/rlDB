KingMod 2026.11.21.0013
Close Rocket League and KingMod before installing. Open KingMod first after updating so verified setup can finish.
Existing settings and game backups are preserved by the installer.
See the update news inside KingMod for feature details and application timing.
